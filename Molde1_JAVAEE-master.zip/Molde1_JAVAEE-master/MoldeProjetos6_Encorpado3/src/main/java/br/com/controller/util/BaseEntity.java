package br.com.controller.util;

public interface BaseEntity {

	 public Long getId(); 
}
