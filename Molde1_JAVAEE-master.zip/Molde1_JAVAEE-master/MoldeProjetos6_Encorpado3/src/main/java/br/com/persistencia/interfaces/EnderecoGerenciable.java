package br.com.persistencia.interfaces;

import br.com.modelo.Endereco;

public interface EnderecoGerenciable {

	public void guardar(Endereco endereco);
}
