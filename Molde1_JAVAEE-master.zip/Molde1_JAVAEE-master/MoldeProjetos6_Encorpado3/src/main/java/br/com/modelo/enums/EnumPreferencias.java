package br.com.modelo.enums;

public enum EnumPreferencias {

	CASA,LOTE,APARTAMENTO,CASA_EM_COND_FECHADO;
}
