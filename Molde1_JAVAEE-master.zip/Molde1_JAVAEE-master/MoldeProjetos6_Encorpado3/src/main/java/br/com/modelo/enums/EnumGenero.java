package br.com.modelo.enums;

public enum EnumGenero {

	MASCULINO,FEMININO;
}
