package br.com.persistencia.interfaces;

import br.com.modelo.Usuario;

public interface UsuarioGerenciable {

	public void guardar(Usuario usuario);
	
}
