package br.com.persistencia.interfaces;

import br.com.modelo.Municipio;

public interface MunicipioGerenciable {

	public void guardar(Municipio municipio);
}
