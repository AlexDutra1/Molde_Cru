package br.com.persistencia.interfaces;

public interface TelefoneGerenciable {

}
