package testes_unitarios.cliente;


public class StartCliente {

	public static void main(String[] args) {

		/*List <Estado> lista=new EstadoDAO(manager).todosEstadosCombo();
	
	
		for (Estado estado : lista) {
			System.out.println("Nome: "+estado.getNome());
		}*/
	}

}
